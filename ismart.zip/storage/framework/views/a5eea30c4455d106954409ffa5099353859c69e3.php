;
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php if(session('status')): ?>
            <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
                <h4 class="alert-heading">Thông báo!</h4>
                <p><?php echo e(session('status')); ?></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Thêm ảnh Slider
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('admin/slider/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Thêm ảnh</label>
                            <input type="file" name="file" id="">
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Trạng thái</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="0"
                                    checked>
                                <label class="form-check-label" for="exampleRadios1">
                                    Chờ duyệt
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                    value="1">
                                <label class="form-check-label" for="exampleRadios2">
                                    Công khai
                                </label>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Danh sách ảnh Slider
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Người tạo</th>
                                <th scope="col">Ngày tạo</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $index = $sliders->perPage() * ($sliders->currentPage() - 1);
                            ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $index++;
                            ?>
                            <tr>
                                <th scope="row"><?php echo e($index); ?></th>
                                <td><img src="<?php echo e(url('/').'/'.$slider->thumbnail); ?>" alt="" style="width: 120px"></td>
                                <td><span
                                        class="badge <?php echo e($slider->status=='1'?'badge-success':'badge-warning'); ?>"><?php echo e($slider->status
                                        =='1'?'Công khai':'Chờ duyệt'); ?></span></td>
                                <td><?php echo e($slider->user->name); ?></td>
                                <td><?php echo e(date('d-m-y', strtotime($slider->created_at))); ?></td>
                                <td>
                                    <?php if($slider->status == 1): ?>
                                    <a href="<?php echo e(url('admin/slider/action', $slider->id)); ?>"
                                        class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Active"><i
                                            class="fas fa-check"></i></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(url('admin/slider/action', $slider->id)); ?>"
                                        class="btn btn-warning btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Pending"> <i
                                            class="fas fa-exclamation-circle"></i></a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('admin/slider/delete', $slider->id)); ?>"
                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/slider/list.blade.php ENDPATH**/ ?>