;
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php if(session('status')): ?>
            <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
                <h4 class="alert-heading">Thông báo!</h4>
                <p><?php echo e(session('status')); ?></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Thêm danh mục
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('admin/post/cat/store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Tên danh mục</label>
                            <input class="form-control" type="text" name="name" id="name">
                        </div>
                        <div class="form-group">
                            <label for="">Danh mục cha</label>
                            <select class="form-control" id="" name="parent_id">
                                <option value="0">Chọn danh mục</option>
                                <?php $__currentLoopData = $post_cats_data_tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($post_cat->id); ?>">
                                    <?php echo e(str_repeat('---/',$post_cat->level).$post_cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Trạng thái</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="0"
                                    checked>
                                <label class="form-check-label" for="exampleRadios1">
                                    Chờ duyệt
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                    value="1">
                                <label class="form-check-label" for="exampleRadios2">
                                    Công khai
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                    <h5 class="m-0 ">Danh mục bài viết</h5>
                    <div class="form-search mt-4">
                        <form action="" class="form-inline">
                            <input type="" class="form-control form-search" placeholder="Tìm kiếm" name="keyword"
                                value="<?php echo e(request()->input('keyword')); ?>">
                            <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tên danh mục</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Người tạo</th>
                                <th scope="col">Ngày tạo</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $index = $post_cats_data_tree_paginate->perPage() * ($post_cats_data_tree_paginate->currentPage()-1);
                            ?>
                            <?php $__currentLoopData = $post_cats_data_tree_paginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $index ++;
                            ?>
                            <tr>
                                <th scope="row"><?php echo e($index); ?></th>
                                <td><?php echo e(str_repeat('---/',$post_cat->level).$post_cat->name); ?></td>
                                <td class="<?php echo e($post_cat->status=='1'?'text-success':'text-danger'); ?>">
                                    <?php echo e($post_cat->status=='1'?'Hoạt động':'Không hoạt động'); ?></td>
                                <td><?php echo e($post_cat->user->name); ?></td>
                                <td><?php echo e(date('d-m-y', strtotime($post_cat->created_at))); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/post/cat/action',$post_cat->id)); ?>"
                                        class="btn btn-sm rounded-0 text-white <?php echo e($post_cat->status=='1'?'btn-success':'btn-warning'); ?>"
                                        type="button" data-toggle="tooltip" data-placement="top"
                                        title="<?php echo e($post_cat->status=='1'?'Active':'InActive'); ?>">
                                        <?php if($post_cat->status == "1"): ?>
                                        <i class="fas fa-check-circle"></i>
                                        <?php else: ?>
                                        <i class="fas fa-exclamation-circle"></i>
                                        <?php endif; ?>
                                    </a>
                                    <a href="<?php echo e(url('admin/post/cat/delete',$post_cat->id)); ?>"
                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($post_cats_data_tree_paginate->withQueryString()->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/post/post-cat.blade.php ENDPATH**/ ?>