;
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách đơn hàng</h5>
            <div class="form-search">
                <form action="<?php echo e(url('admin/order/list')); ?>" method="GET" class="form-inline">
                    <input type="" class="form-control form-search" placeholder="Tìm kiếm theo tên" name="keyword" value="<?php echo e(request()->input('keyword')); ?>">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
            <h4 class="alert-heading">Thông báo!</h4>
            <p><?php echo e(session('status')); ?></p>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="analytic">
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'all'])); ?>" class="text-primary">Toàn bộ<span class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'pending'])); ?>" class="text-primary">Đang xử lý<span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'delivery'])); ?>" class="text-primary">Đang giao hàng<span class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'success'])); ?>" class="text-primary">Hoàn thành<span class="text-muted">(<?php echo e($count[3]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'cancel'])); ?>" class="text-primary">Hủy đơn<span class="text-muted">(<?php echo e($count[4]); ?>)</span></a>
            </div>
            <table class="mt-5 table table-striped table-checkall">
                <thead>
                    <tr>
                        <th>
                            <input type="checkbox" name="checkall">
                        </th>
                        <th scope="col">#</th>
                        <th scope="col">Mã</th>
                        <th scope="col">Khách hàng</th>
                        <th scope="col">Số điện thoại</th>
                        <th scope="col">Tổng giá trị</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Thời gian</th>
                        <th scope="col">Tác vụ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $index = $orders->perPage() * ($orders->currentPage() - 1);
                    ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $index++
                    ?>
                    <tr>
                        <td>
                            <input type="checkbox">
                        </td>
                        <td><?php echo e($index); ?></td>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->name); ?></td>
                        <td> <?php echo e($order->phone); ?></td>
                        <td><?php echo e(currency_format($order->total_price($order->id))); ?></td>
                        <td>
                            <?php if($order->status_id == "1"): ?>
                            <span class="badge badge-danger"><?php echo e($order->order_status->name); ?></span>
                            <?php elseif($order->status_id == "2"): ?>
                            <span class="badge badge-warning"><?php echo e($order->order_status->name); ?></span>
                            <?php elseif($order->status_id == "3"): ?>
                            <span class="badge badge-success"><?php echo e($order->order_status->name); ?></span>
                            <?php else: ?>
                            <span class="badge badge-dark"><?php echo e($order->order_status->name); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(date('d-m-y', strtotime($order->created_at))); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/order/detail', $order->id)); ?>"
                                class="btn btn-success btn-sm rounded-0 text-white" type="button" data-toggle="tooltip"
                                data-placement="top" title="Detail"><i class="fas fa-eye"></i></a>
                            <a href="<?php echo e(url('admin/order/delete', $order->id)); ?>" class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                data-toggle="tooltip" data-placement="top" title="Delete"><i
                                    class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($orders->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/order/list.blade.php ENDPATH**/ ?>