;
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 py-4">Thông tin đơn hàng</h5>
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
            <h4 class="alert-heading">Thông báo!</h4>
            <p><?php echo e(session('status')); ?></p>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <h5 class="mb-3">Thông tin khách hàng</h5>
            <table class="table table-striped table-checkall">
                <thead>
                    <tr>
                        <th scope="col">Họ và tên</th>
                        <th scope="col">Mã đơn hàng</th>
                        <th scope="col">Số điện thoại</th>
                        <th scope="col">Địa chỉ</th>
                        <th scope="col">Email</th>
                        <th scope="col">Thời gian đặt hàng</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->address); ?></td>
                        <td><?php echo e($order->email); ?></td>
                        <td><?php echo e(date('d-m-y', strtotime($order->created_at))); ?></td>
                    </tr>
                </tbody>
            </table>
            <h5 class="mt-4 mb-3">Tình trạng đơn hàng</h5>
            <form action="<?php echo e(url('admin/order/update', $order->id)); ?>" method="POST" class="form-inline">
                <?php echo csrf_field(); ?>
                <div class="col-4 pl-0">
                    <select class="custom-select" name="status_id">
                        <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($order->status_id == $status->id?'selected':''); ?>

                            value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" value="Cập nhật" name="btn-submit" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 py-4">Chi tiết đơn hàng</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-checkall">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Ảnh</th>
                        <th scope="col">Tên sản phẩm</th>
                        <th scope="col">Giá</th>
                        <th scope="col">Số lượng</th>
                        <th scope="col">Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $index = 0;
                    ?>
                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $index ++;
                    ?>
                    <tr>
                        <td><?php echo e($index); ?></td>
                        <td><img src="<?php echo e(url('/').'/'.$product->product_thumbnail_details[0]->thumbnail); ?>" alt="" style="width: 120px"></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e(currency_format($product->price)); ?></td>
                        <td><?php echo e($product->pivot->quantity); ?></td>
                        <td><?php echo e(currency_format($product->pivot->total)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h5 class="text-right mt-4 text-success">Tổng giá trị đơn hàng: <span><?php echo e(currency_format($order->total_price($order->id))); ?></span></h5>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>