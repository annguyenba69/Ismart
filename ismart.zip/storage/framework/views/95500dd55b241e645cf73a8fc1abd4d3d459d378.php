<ul class="sub-menu">
    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('product.show',['cat_id'=>$category->id,'slug'=>$category->slug])); ?>" title=""><?php echo e($category->name); ?></a>
        <?php if($category->subcategories->isNotEmpty()): ?>
            <?php echo $__env->make('ismart.home.subcategories', ['subcategories'=>$category->subcategories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/ismart/home/subcategories.blade.php ENDPATH**/ ?>