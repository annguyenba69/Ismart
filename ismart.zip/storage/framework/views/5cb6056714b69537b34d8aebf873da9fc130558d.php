
<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Blog</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="list-blog-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title">Bài viết</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('post.detail',['post_id'=>$post->id,'post_slug'=>$post->slug])); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(url('/').'/'.$post->thumbnail); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('post.detail',['post_id'=>$post->id,'post_slug'=>$post->slug])); ?>" title="" class="title"><?php echo e($post->title); ?></a>
                                <span class="create-date"><?php echo e($post->created_at); ?></span>
                                <p>Danh Mục: <span class="text-muted"><?php echo e($post->post_parent_category[0]->name); ?></span>
                                </p>
                                <div>
                                    <p class="desc"><?php echo limit_text($post->content,50); ?></p>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="paging-wp">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm bán chạy</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('product.detail',['cat_id'=>$product->get_parent_category[0]->id,
                                'slug'=>$product->get_parent_category[0]->slug, 'product_id'=>$product->id,
                                 'product_slug'=>$product->slug])); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(url('/').'/'.$product->product_thumbnail_details[0]->thumbnail); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('product.detail',['cat_id'=>$product->get_parent_category[0]->id,
                                    'slug'=>$product->get_parent_category[0]->slug, 'product_id'=>$product->id,
                                     'product_slug'=>$product->slug])); ?>" title="" class="product-name"><?php echo e($product->name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(currency_format($product->price)); ?></span>
                                </div>
                                <a href="<?php echo e(url('gio-hang/mua-ngay',$product->id)); ?>" title="" class="buy-now">Mua ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_blog_product" title="" class="thumb">
                        <img src="public/images/banner.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ismart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/ismart/post/index.blade.php ENDPATH**/ ?>