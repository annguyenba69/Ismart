;
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php if(session('status')): ?>
            <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
                <h4 class="alert-heading">Thông báo!</h4>
                <p><?php echo e(session('status')); ?></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Danh mục sản phẩm
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('admin/product/cat/store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Tên danh mục</label>
                            <input class="form-control" type="text" name="name" id="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Danh mục cha</label>
                            <select class="form-control" id="" name="parent_id">
                                <option value="0">Chọn danh mục</option>
                                <?php $__currentLoopData = $product_cats_data_tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product_cat->id); ?>">
                                    <?php echo e(str_repeat('---/',$product_cat->level).$product_cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Trạng thái</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="0"
                                    checked>
                                <label class="form-check-label" for="exampleRadios1">
                                    Chờ duyệt
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                    value="1">
                                <label class="form-check-label" for="exampleRadios2">
                                    Công khai
                                </label>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                    <h5 class="m-0 ">Danh mục sản phẩm</h5>
                    <div class="form-search mt-4">
                        <form action="" class="form-inline">
                            <input type="<?php echo e(url('admin/product/cat/index')); ?>" class="form-control form-search" placeholder="Tìm kiếm" name="keyword"
                                value="<?php echo e(request()->input('keyword')); ?>">
                            <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tên Danh Mục</th>
                                <th scope="col">Trạng Thái</th>
                                <th scope="col">Người Tạo</th>
                                <th scope="col">Ngày Tạo</th>
                                <th scope="col">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $index =
                            $product_cats_data_tree_pagination->perPage()*($product_cats_data_tree_pagination->currentPage()
                            - 1)
                            ?>
                            <?php $__currentLoopData = $product_cats_data_tree_pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $index++
                            ?>
                            <tr>
                                <th scope="row"><?php echo e($index); ?></th>
                                <td><?php echo e(str_repeat('---/',$product_cat->level).$product_cat->name); ?></td>
                                <td class="<?php echo e($product_cat->status==1?'text-success':'text-danger'); ?>">
                                    <?php echo e($product_cat->status==1?'Hoạt động':'Không hoạt động'); ?></td>
                                <td><?php echo e($product_cat->user->name); ?></td>
                                <td><?php echo e(date('d-m-y', strtotime($product_cat->created_at))); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/product/cat/action',$product_cat->id)); ?>"
                                        class="btn btn-sm rounded-0 text-white <?php echo e($product_cat->status=='1'?'btn-success':'btn-warning'); ?>" type="button"
                                        data-toggle="tooltip" data-placement="top" title="<?php echo e($product_cat->status=='1'?'Active':'InActive'); ?>">
                                        <?php if($product_cat->status == "1"): ?>
                                        <i class="fas fa-check-circle"></i>
                                        <?php else: ?>
                                        <i class="fas fa-exclamation-circle"></i>
                                        <?php endif; ?>
                                    </a>
                                    <a href="<?php echo e(url('admin/product/cat/delete',$product_cat->id)); ?>" class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($product_cats_data_tree_pagination->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/product/product-cat.blade.php ENDPATH**/ ?>