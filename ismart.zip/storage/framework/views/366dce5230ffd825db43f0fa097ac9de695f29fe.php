
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="category-news-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title=""><?php echo e($page->name); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="clearfix wp-inner">
            <div id="content" class="fl-left">
                <?php echo $page->content; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ismart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/ismart/page/index.blade.php ENDPATH**/ ?>