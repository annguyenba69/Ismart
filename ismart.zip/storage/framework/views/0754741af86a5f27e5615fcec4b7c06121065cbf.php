
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách trang</h5>
            <div class="form-search ">
                <form action="#" class="form-inline">
                    <input type="" class="form-control form-search" placeholder="Tìm kiếm" name="keyword"
                        value="<?php echo e(request()->input('keyword')); ?>">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-dismissible <?php echo e(session('class')); ?>" role="alert">
            <h4 class="alert-heading">Thông báo!</h4>
            <p><?php echo e(session('status')); ?></p>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="analytic">
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'active'])); ?>" class="text-primary">Hoạt động<span
                        class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status'=>'trash'])); ?>" class="text-primary">Thùng rác<span
                        class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
            </div>
            <form action="<?php echo e(url('admin/page/action')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-action form-inline py-3">
                    <select class="form-control mr-1" id="" name="action">
                        <option value="">Chọn</option>
                        <?php $__currentLoopData = $list_action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($action); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                </div>
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th scope="col">
                                <input name="checkall" type="checkbox">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col">Tên trang</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Người tạo</th>
                            <th scope="col">Ngày tạo</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $index = $pages->perPage() * ($pages->currentPage() - 1);
                        ?>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $index ++;
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="list_pages[]" value="<?php echo e($page->id); ?>">
                            </td>
                            <td scope="row"><?php echo e($index); ?></td>
                            <td><?php echo e($page->name); ?></td>
                            <td><span class="badge <?php echo e($page->status=="
                                    1"?"badge-success":"badge-danger"); ?>"><?php echo e($page->status=="1"?"Hoạt động":"Không hoạt
                                    động"); ?></span></td>
                            <td><?php echo e($page->user->name); ?></td>
                            <td><?php echo e(date('d-m-y', strtotime($page->created_at))); ?></td>
                            <td>
                                <?php if($page->deleted_at == null): ?>
                                <a href="<?php echo e(url('admin/page/edit', $page->id)); ?>"
                                    class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                        class="fa fa-edit"></i></a>
                                <?php else: ?>
                                <a href="<?php echo e(url('admin/page/restore', $page->id)); ?>"
                                    class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                    data-toggle="tooltip" data-placement="top" title="Restore"><i
                                        class="fas fa-undo"></i></a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('admin/page/delete', $page->id)); ?>"
                                    class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                        class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </form>
            <?php echo e($pages->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ismart\resources\views/admin/page/list.blade.php ENDPATH**/ ?>